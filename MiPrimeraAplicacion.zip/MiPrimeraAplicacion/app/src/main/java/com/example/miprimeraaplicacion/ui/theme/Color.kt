package com.example.miprimeraaplicacion.ui.theme

import androidx.compose.ui.graphics.Color

val Teal80 = Color(0xFF80CBC4)
val TealGrey80 = Color(0xFFB0BEC5)
val Orange80 = Color(0xFFFFCC80)

val Teal40 = Color(0xFF00796B)
val TealGrey40 = Color(0xFF546E7A)
val Orange40 = Color(0xFFEF6C00)

val FondoTema = Color(0xFFFF0000)