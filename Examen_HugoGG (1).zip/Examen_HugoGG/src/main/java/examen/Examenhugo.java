package examen;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Examenhugo { 
    public static void main(String[] args) { 
        Connection conexion = null; 
        try { 
            conexion = obtenerConexion(); 
             
            ejercicio3(conexion); 
           // ejercicio4(conexion); 
             
        } catch (SQLException e) { 
            System.err.println("Error al conectar con la base de datos: " + e.getMessage()); 
            e.printStackTrace(); 
        } finally { 
            if (conexion != null) { 
                try { 
                    conexion.close(); 
                } catch (SQLException e) { 
                    System.err.println("Error al cerrar la conexión: " + e.getMessage()); 
                } 
            } 
        } 
    } 
 
    private static Connection obtenerConexion() throws SQLException {
        return DriverManager.getConnection(
            "jdbc:mysql://192.168.13.100:3306/examen_Hugo?useSSL=false&serverTimezone=UTC",
            "root", "practicas"
        );
    }
    
    /*
    
*/
    private static void ejercicio4(Connection conexion) throws SQLException { 
  
    	System.out.println("Introduce el id del cliente");
    	Scanner in = new Scanner(System.in);
    	int id = in.nextInt();
        String sql = "SELECT rpad(ID, 15, ' '), rpad(NOMBRE, 15, ' '), rpad(DIRECCION, 15, ' '), rpad(POBLACION, 15, ' '), rpad(TELEFONO, 15, ' '),rpad(NIF, 15, ' ') FROM CLIENTES WHERE ID = ?;" ; 
        PreparedStatement ps = conexion.prepareStatement(sql);

        ps.setInt(1, id); 

        ResultSet rs = ps.executeQuery();
        try (Statement sentencia = conexion.createStatement(); 
             ResultSet resul = sentencia.executeQuery(sql)) { 
             
            System.out.println("=============================================="); 
            System.out.println("Ventas del cliente "+ resul.getString(1)); 
            System.out.println("Venta "+ resul.getString(0));
 
            while (resul.next()) { 
                System.out.println(resul.getString(1) + " " + resul.getString(2) + " " + resul.getFloat(3)); 
            } 
            System.out.println("=========================================================================="); 
             
        } catch (SQLException e) { 
            System.err.println("Error al ejecutar la consulta SQL en parte1Actividad6: " + e.getMessage()); 
            e.printStackTrace(); 
        } 
    } 
   
 
    private static void ejercicio3(Connection conexion) { 
    	System.out.println("Introduce 1 o 2");
    	Scanner in = new Scanner(System.in);
    	int n = in.nextInt();
    	String tres;
    	if (n == 1) {
    		tres = "SELECT ID, NOMBRE, DIRECCION, POBLACION, TELEF, NIF FROM CLIENTES; ";
    	}else {
    		tres = "SELECT ID, DESCRIPCION, STOCKACTUAL, STOCKMINIMO, PVP FROM PRODUCTOS;";
    	}
    	
    	
     try (Statement sentencia = conexion.createStatement(); 
         ResultSet resul = sentencia.executeQuery(tres)) { 
         System.out.print("ID: "); 
         if (resul.next()) { 
        	 if(n==1) {
        		 System.out.printf("%s, NOMBRE: %s, DIRECCION: %s, POBLACION: %s, TELEFONO: %s, NIF: %s %n", 
                         resul.getString(0), resul.getString(1), resul.getString(2), resul.getString(3), resul.getString(4), resul.getString(5));
        	 }else {
        		 System.out.printf("%s, DESCRIPCION: %s, STOCKACTUAL: %s, STOCKMINIMO: %s, PVP: %s %n", 
                         resul.getInt(0), resul.getString(1), resul.getInt(2), resul.getInt(3), resul.getFloat(4));
        	 }
              
         }
         resul.close();
         System.out.println("=========================================================================="); 

     } catch (SQLException e) { 
         System.err.println("Error al ejecutar la consulta SQL en ejercicio3: " + e.getMessage()); 
         e.printStackTrace(); 
     } 
 } 
} 
